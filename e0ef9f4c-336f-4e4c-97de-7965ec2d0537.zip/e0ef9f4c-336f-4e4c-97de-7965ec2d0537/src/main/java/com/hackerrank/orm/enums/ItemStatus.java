package com.hackerrank.orm.enums;

public enum ItemStatus {
    SOLD,
    AVAILABLE;
}
